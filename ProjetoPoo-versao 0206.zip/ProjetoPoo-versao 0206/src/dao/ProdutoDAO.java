package dao;

public class ProdutoDAO {
}
