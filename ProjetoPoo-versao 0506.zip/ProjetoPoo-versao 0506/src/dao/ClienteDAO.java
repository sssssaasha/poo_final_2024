package dao;

public class ClienteDAO {
}
