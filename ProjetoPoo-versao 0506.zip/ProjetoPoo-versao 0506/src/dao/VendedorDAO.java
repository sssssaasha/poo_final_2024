package dao;

public class VendedorDAO {
}
