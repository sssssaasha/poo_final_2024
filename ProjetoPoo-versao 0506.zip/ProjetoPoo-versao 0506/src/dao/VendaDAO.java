package dao;

public class VendaDAO {

}
