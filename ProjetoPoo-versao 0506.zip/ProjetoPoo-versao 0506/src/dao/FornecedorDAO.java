package dao;

public class FornecedorDAO {
}
